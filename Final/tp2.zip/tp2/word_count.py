'''This is a script for counting words using Mapreduce in the text file. Enter the required parameters
and run as python3 wordCount.py'''
from nltk.corpus import stopwords
from pyspark import SparkContext
import boto3
import re
import string
from nltk.stem import *
import nltk
import sys

aws_key_id='', #Change here, set your s3 access key id
aws_secret_key='', #Change here, set your s3 secret access key

#Set the bucket and input file name
s3_bucket = '' #Change here, set your bucket name
input_name = '' #Change here. Set your filename in the bucket
output_name = '' #Change here. Set your filename to save in the bucket

nltk.download('stopwords')

def clean_str(x):
    x = x.lower()
    clean_str = re.sub(r'^\W+|\W+$', '', x)
    return re.split(r'\W+', clean_str)


def stemWord(word):
    porter = PorterStemmer()
    word = porter.stem(word)
    return word


if __name__ == '__main__':


    try:
        print('Initialising the s3 bucket...', end ="   "),
        s3 = boto3.client(
        's3',
        aws_access_key_id=''.join(aws_key_id), #your s3 access key id
        aws_secret_access_key=''.join(aws_secret_key), #your s3 secret access key
        )
        print('DONE')
    except Exception as e:
        print('Error! Did you set the s3 credentials correctly?')
        print(e)
        sys.exit('Please open the script and set the credentials. Exiting...')

    s3 = boto3.client('s3')
    s3.download_file(s3_bucket, input_name, output_name)  # downoloading file from S3


    sc = SparkContext("local", "wordcount")

    stopWords = set(stopwords.words('english'))

    rdd = sc.textFile('result.txt')  # creating rdd

    rdd = rdd.filter(lambda x: len(x) > 0)  # delete empty lines

    rdd = rdd.flatMap(lambda x: clean_str(x))  # 'clean' the text line by line and split it in words

    rdd = rdd.filter(lambda x: x not in stopWords)  # remove stopwords

    rdd = rdd.map(lambda x: stemWord(x))  # stemm the words

    rdd = rdd.map(lambda x: (x, 1)) #  perform mapReduce

    rdd = rdd.reduceByKey(lambda x, y: x + y)

    rdd = rdd.map(lambda x: (x[1], x[0]))

    rdd = rdd.sortByKey(False)

    print(rdd.take(20))
